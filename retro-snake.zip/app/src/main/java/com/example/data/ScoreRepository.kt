package com.example.data

import kotlinx.coroutines.flow.Flow

class ScoreRepository(private val scoreDao: ScoreDao) {
    val allHighScores: Flow<List<ScoreEntry>> = scoreDao.getAllHighScores()

    fun getHighScoreForConfig(gameMode: String, difficulty: String): Flow<Int?> {
        return scoreDao.getHighScoreForConfig(gameMode, difficulty)
    }

    suspend fun insertScore(scoreEntry: ScoreEntry) {
        scoreDao.insertScore(scoreEntry)
    }

    suspend fun clearAllScores() {
        scoreDao.clearAllScores()
    }
}
