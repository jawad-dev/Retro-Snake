package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ScoreEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(viewModel: GameViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val highScores by viewModel.highScores.collectAsStateWithLifecycle()

    // Determine colors based on active theme
    val themeColors = remember(state.theme) { getThemeColors(state.theme) }

    // Edge-to-edge content container
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = themeColors.background
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isLandscape = maxWidth > maxHeight
            val isTablet = maxWidth > 600.dp

            if (isTablet || isLandscape) {
                // Wide Screen Side-By-Side Adaptive Canonical Layout
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // Left Side: Main Play Panel or Menu Panel
                    Box(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!state.hasStarted) {
                            MenuPanel(
                                state = state,
                                viewModel = viewModel,
                                themeColors = themeColors
                            )
                        } else {
                            ActivePlayPanel(
                                state = state,
                                viewModel = viewModel,
                                themeColors = themeColors,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    // Right Side: High Score Leaderboard and Quick Settings Panel
                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(16.dp))
                            .background(themeColors.surface)
                            .border(1.dp, themeColors.accent.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        LeaderboardSection(
                            highScores = highScores,
                            themeColors = themeColors,
                            modifier = Modifier.weight(1f),
                            onClearClick = { viewModel.clearHighScores() }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        HorizontalDivider(color = themeColors.accent.copy(alpha = 0.2f))

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Theme Toggle on Game screen
                        QuickThemeSelectorSection(
                            currentTheme = state.theme,
                            themeColors = themeColors,
                            onThemeSelected = { viewModel.changeTheme(it) }
                        )
                    }
                }
            } else {
                // Standard Compact Portrait Layout (Stacked)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!state.hasStarted) {
                        MenuPanel(
                            state = state,
                            viewModel = viewModel,
                            themeColors = themeColors
                        )
                    } else {
                        ActivePlayPanel(
                            state = state,
                            viewModel = viewModel,
                            themeColors = themeColors,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Game Over overlay dialog (Custom Animated Overlay rather than plain blocking pop-up)
        AnimatedVisibility(
            visible = state.isGameOver,
            enter = fadeIn() + scaleIn(initialScale = 0.9f),
            exit = fadeOut()
        ) {
            GameOverOverlay(
                state = state,
                viewModel = viewModel,
                themeColors = themeColors
            )
        }
    }
}

@Composable
fun MenuPanel(
    state: SnakeGameState,
    viewModel: GameViewModel,
    themeColors: ThemeColors
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Glowing Title Hero section
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Text(
                text = "RETRO SNAKE",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = themeColors.accent,
                textAlign = TextAlign.Center,
                modifier = Modifier.shadow(8.dp, clip = false)
            )
            Text(
                text = "A modern 2D Arcade Classic",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.SansSerif,
                color = themeColors.textSecondary,
                textAlign = TextAlign.Center
            )
        }

        // Main Config Card (Single styled Card avoiding gray defaults)
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false),
            colors = CardDefaults.elevatedCardColors(
                containerColor = themeColors.surface
            ),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Customize Arena Configuration",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColors.accent,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                // Game Mode selection
                item {
                    Column {
                        Text(
                            text = "Game Mode",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = themeColors.textPrimary
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GameMode.values().forEach { mode ->
                                val selected = state.selectedMode == mode
                                Button(
                                    onClick = { viewModel.changeGameMode(mode) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("mode_${mode.name.lowercase()}"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) themeColors.primary else themeColors.unselected,
                                        contentColor = if (selected) themeColors.textOnPrimary else themeColors.textSecondary
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                                ) {
                                    Text(text = mode.label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            text = state.selectedMode.description,
                            fontSize = 11.sp,
                            color = themeColors.textSecondary,
                            modifier = Modifier.padding(top = 4.dp, start = 2.dp)
                        )
                    }
                }

                // Difficulty selection
                item {
                    Column {
                        Text(
                            text = "Difficulty Speed",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = themeColors.textPrimary
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Difficulty.values().forEach { difficulty ->
                                val selected = state.selectedDifficulty == difficulty
                                Button(
                                    onClick = { viewModel.changeDifficulty(difficulty) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("difficulty_${difficulty.name.lowercase()}"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) themeColors.primary else themeColors.unselected,
                                        contentColor = if (selected) themeColors.textOnPrimary else themeColors.textSecondary
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                                ) {
                                    Text(text = difficulty.label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Walls Options / Wrap Around
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(themeColors.unselected.copy(alpha = 0.5f))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Wrap Around Walls",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = themeColors.textPrimary
                            )
                            Text(
                                text = "Pass safely through wall to other side",
                                fontSize = 11.sp,
                                color = themeColors.textSecondary
                            )
                        }
                        Switch(
                            checked = state.wrapAround,
                            onCheckedChange = { viewModel.toggleWrapAround(it) },
                            modifier = Modifier.testTag("wrap_walls_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = themeColors.accent,
                                checkedTrackColor = themeColors.primary,
                                uncheckedThumbColor = themeColors.textSecondary,
                                uncheckedTrackColor = themeColors.unselected
                            )
                        )
                    }
                }

                // Dynamic visual Theme engine selector
                item {
                    Column {
                        Text(
                            text = "Aesthetic Retro Theme",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = themeColors.textPrimary
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ThemePalette.values().forEach { themePalette ->
                                val selected = state.theme == themePalette
                                val themePalColors = getThemeColors(themePalette)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(themePalColors.background)
                                        .border(
                                            width = if (selected) 2.dp else 1.dp,
                                            color = if (selected) themeColors.accent else themePalColors.accent.copy(alpha = 0.4f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable { viewModel.changeTheme(themePalette) }
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = themePalette.label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = themePalColors.accent,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Start High-Volume Action button (Minimum 48dp target)
        Button(
            onClick = { viewModel.startGame() },
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(56.dp)
                .shadow(12.dp, RoundedCornerShape(16.dp))
                .testTag("start_game_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = themeColors.accent,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.Black)
                Text(
                    text = "LAUNCH ARENA",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Leaderboard toggle option for Compact screens at the bottom of menu
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(Icons.Filled.Star, contentDescription = "Record", tint = themeColors.accent, modifier = Modifier.size(16.dp))
                Text(
                    text = "Current Record: ${state.currentHighScore} pts",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = themeColors.textPrimary
                )
            }
        }
    }
}

@Composable
fun ActivePlayPanel(
    state: SnakeGameState,
    viewModel: GameViewModel,
    themeColors: ThemeColors,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Live Header: Scoreboard
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(themeColors.surface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "SCORE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeColors.textSecondary,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%04d", state.score),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = themeColors.accent,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Game metadata badge
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${state.selectedMode.label} • ${state.selectedDifficulty.label}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeColors.textPrimary
                )
                if (state.wrapAround) {
                    Text(
                        text = "WRAP WALLS ON",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColors.primary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Quick Control Toggles
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.setMuted(!viewModel.soundManager.isMuted) },
                    modifier = Modifier.testTag("mute_toggle_button")
                ) {
                    Icon(
                        imageVector = if (viewModel.soundManager.isMuted) Icons.Filled.PlayArrow else Icons.Filled.Notifications, // Outlined bell/off
                        contentDescription = "Mute",
                        tint = themeColors.textPrimary
                    )
                }

                IconButton(
                    onClick = { viewModel.pauseResumeGame() },
                    modifier = Modifier
                        .background(
                            if (state.isPaused) themeColors.primary else themeColors.unselected,
                            CircleShape
                        )
                        .testTag("pause_resume_button")
                ) {
                    Icon(
                        imageVector = if (state.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Refresh, // Standard Pause/Play symbols
                        contentDescription = "Pause",
                        tint = if (state.isPaused) themeColors.textOnPrimary else themeColors.textPrimary
                    )
                }
            }
        }

        // Golden food bonus active countdown bar
        if (state.specialFood != null) {
            val progress = state.specialFoodExpiry.toFloat() / 15f
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "GOLDEN APPLE ACTIVE! (Worth 30 pts)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    )
                    Text(
                        text = "${state.specialFoodExpiry}s",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    )
                }
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFFFFD700),
                    trackColor = themeColors.unselected
                )
            }
        } else {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Primary 2D Canvas Play Board
        Box(
            modifier = Modifier
                .weight(1f)
                .aspectRatio(1f) // Constrain to 1:1 square
                .shadow(12.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(themeColors.gridBg)
                .border(2.dp, themeColors.accent, RoundedCornerShape(12.dp))
        ) {
            GameBoardCanvas(
                state = state,
                gridSize = viewModel.gridSize,
                themeColors = themeColors,
                onSwipe = { swipeDir -> viewModel.changeDirection(swipeDir) }
            )

            // Paused visual overlay
            if (state.isPaused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "GAME PAUSED",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = themeColors.accent
                        )
                        Text(
                            text = "Tap Play arrow to resume",
                            fontSize = 12.sp,
                            color = themeColors.textSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Multi-Input Controls: Swipe support built into Canvas, Virtual D-pad beneath
        VirtualDpad(
            activeDirection = state.direction,
            onDirectionChange = { viewModel.changeDirection(it) },
            isPaused = state.isPaused,
            onPauseToggle = { viewModel.pauseResumeGame() },
            themeColors = themeColors
        )
    }
}

@Composable
fun GameBoardCanvas(
    state: SnakeGameState,
    gridSize: Int,
    themeColors: ThemeColors,
    onSwipe: (Direction) -> Unit
) {
    // Pulse animation logic for drawing items
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Touch swipe gesture state
    var touchStartX by remember { mutableFloatStateOf(0f) }
    var touchStartY by remember { mutableFloatStateOf(0f) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        touchStartX = offset.x
                        touchStartY = offset.y
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                    },
                    onDragEnd = {
                        // Calculate final total drag
                        val deltaX = touchStartX // Placeholder, wait, onDrag triggers continually, but standard detectDragGestures handles swipe beautifully
                    }
                )
            }
            // Alternative swipe detection
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        touchStartX = offset.x
                        touchStartY = offset.y
                    },
                    onDrag = { change, _ ->
                        val diffX = change.position.x - touchStartX
                        val diffY = change.position.y - touchStartY
                        
                        // Limit swipe detection triggering to substantial movements
                        if (Math.abs(diffX) > 60f || Math.abs(diffY) > 60f) {
                            if (Math.abs(diffX) > Math.abs(diffY)) {
                                if (diffX > 0) onSwipe(Direction.RIGHT) else onSwipe(Direction.LEFT)
                            } else {
                                if (diffY > 0) onSwipe(Direction.DOWN) else onSwipe(Direction.UP)
                            }
                            // Reset tracking points so single sweep doesn't repeatedly fire
                            touchStartX = change.position.x
                            touchStartY = change.position.y
                        }
                    }
                )
            }
    ) {
        val cellSizeWidth = size.width / gridSize
        val cellSizeHeight = size.height / gridSize

        // 1. Draw grid coordinate background lines
        for (i in 1 until gridSize) {
            // Vertical lines
            drawLine(
                color = themeColors.gridLine,
                start = Offset(i * cellSizeWidth, 0f),
                end = Offset(i * cellSizeWidth, size.height),
                strokeWidth = 1f
            )
            // Horizontal lines
            drawLine(
                color = themeColors.gridLine,
                start = Offset(0f, i * cellSizeHeight),
                end = Offset(size.width, i * cellSizeHeight),
                strokeWidth = 1f
            )
        }

        // 2. Draw static stone obstacles
        state.obstacles.forEach { pos ->
            drawObstacleCell(pos, cellSizeWidth, cellSizeHeight, themeColors)
        }

        // 3. Draw pulsing Food (Normal Apple)
        drawAppleCell(
            pos = state.food,
            cellWidth = cellSizeWidth,
            cellHeight = cellSizeHeight,
            scale = pulseScale,
            color = themeColors.apple,
            isSpecial = false
        )

        // 4. Draw pulsing Golden Special Apple (If active)
        state.specialFood?.let { specialPos ->
            drawAppleCell(
                pos = specialPos,
                cellWidth = cellSizeWidth,
                cellHeight = cellSizeHeight,
                scale = pulseScale * 1.15f,
                color = Color(0xFFFFD700),
                isSpecial = true
            )
        }

        // 5. Draw fully custom stylized Snake
        state.snake.forEachIndexed { index, pos ->
            val isHead = index == 0
            val color = if (isHead) {
                themeColors.snakeHead
            } else {
                // Gradient gradient scale body segments from head to tail
                val fraction = index.toFloat() / state.snake.size.coerceAtLeast(1)
                interpolateColor(themeColors.snakeHead, themeColors.snakeTail, fraction)
            }

            // Taper sizing
            val scaleFactor = if (isHead) 0.95f else {
                // Taper body slightly down to tail
                val fraction = 1f - (index.toFloat() / state.snake.size.toFloat()) * 0.35f
                fraction.coerceIn(0.6f, 0.9f)
            }

            drawSnakeSegment(
                pos = pos,
                cellWidth = cellSizeWidth,
                cellHeight = cellSizeHeight,
                scale = scaleFactor,
                color = color,
                isHead = isHead,
                direction = state.direction
            )
        }
    }
}

fun DrawScope.drawObstacleCell(
    pos: Pair<Int, Int>,
    cellWidth: Float,
    cellHeight: Float,
    themeColors: ThemeColors
) {
    val x = pos.first * cellWidth
    val y = pos.second * cellHeight
    val padding = cellWidth * 0.08f

    // Heavy slate blocks
    drawRoundRect(
        color = themeColors.obstacleColor,
        topLeft = Offset(x + padding, y + padding),
        size = Size(cellWidth - padding * 2, cellHeight - padding * 2),
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
    )

    // Draw inner cross texture so it looks cracked/rocky
    drawRoundRect(
        color = Color.Black.copy(alpha = 0.5f),
        topLeft = Offset(x + padding, y + padding),
        size = Size(cellWidth - padding * 2, cellHeight - padding * 2),
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
        style = Stroke(width = 1.5.dp.toPx())
    )

    // Small diagonal crack lines
    drawLine(
        color = Color.Black.copy(alpha = 0.4f),
        start = Offset(x + padding, y + padding),
        end = Offset(x + cellWidth - padding, y + cellHeight - padding),
        strokeWidth = 1.dp.toPx()
    )
}

fun DrawScope.drawAppleCell(
    pos: Pair<Int, Int>,
    cellWidth: Float,
    cellHeight: Float,
    scale: Float,
    color: Color,
    isSpecial: Boolean
) {
    val centerX = pos.first * cellWidth + cellWidth / 2
    val centerY = pos.second * cellHeight + cellHeight / 2
    val baseRadius = (cellWidth / 2) * 0.8f
    val radius = baseRadius * scale

    // Apple body glow background
    drawCircle(
        color = color.copy(alpha = 0.25f),
        radius = radius * 1.4f,
        center = Offset(centerX, centerY)
    )

    // Dynamic shapes
    if (isSpecial) {
        // Star or golden shape
        val path = Path().apply {
            val numPoints = 5
            var angle = -Math.PI / 2
            val angleStep = Math.PI / numPoints
            
            for (i in 0 until numPoints * 2) {
                val r = if (i % 2 == 0) radius else radius * 0.4f
                val x = (centerX + Math.cos(angle) * r).toFloat()
                val y = (centerY + Math.sin(angle) * r).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
                angle += angleStep
            }
            close()
        }
        drawPath(path = path, color = color)
    } else {
        // Standard juicy apple sphere
        drawCircle(
            color = color,
            radius = radius,
            center = Offset(centerX, centerY)
        )

        // Draw leaf/stem
        val stemStart = Offset(centerX, centerY - radius * 0.7f)
        val stemEnd = Offset(centerX + cellWidth * 0.15f, centerY - radius * 1.3f)
        drawLine(
            color = Color(0xFF8B4513), // Brown stem
            start = stemStart,
            end = stemEnd,
            strokeWidth = 2.dp.toPx()
        )
        // Green leaf
        drawCircle(
            color = Color(0xFF32CD32),
            radius = radius * 0.3f,
            center = Offset(stemEnd.x + 2.dp.toPx(), stemEnd.y)
        )
    }
}

fun DrawScope.drawSnakeSegment(
    pos: Pair<Int, Int>,
    cellWidth: Float,
    cellHeight: Float,
    scale: Float,
    color: Color,
    isHead: Boolean,
    direction: Direction
) {
    val centerX = pos.first * cellWidth + cellWidth / 2
    val centerY = pos.second * cellHeight + cellHeight / 2

    val width = cellWidth * scale
    val height = cellHeight * scale

    val topLeftX = centerX - width / 2
    val topLeftY = centerY - height / 2

    // Draw snake segment block
    drawRoundRect(
        color = color,
        topLeft = Offset(topLeftX, topLeftY),
        size = Size(width, height),
        cornerRadius = CornerRadius(
            x = if (isHead) 8.dp.toPx() else 4.dp.toPx(),
            y = if (isHead) 8.dp.toPx() else 4.dp.toPx()
        )
    )

    // If it's the snake head, draw two expressive retro eyes looking in current movement direction!
    if (isHead) {
        val eyeSize = width * 0.18f
        val pupilSize = eyeSize * 0.5f

        // Offset eye positions relative to head direction
        val eyeOffset1: Offset
        val eyeOffset2: Offset

        when (direction) {
            Direction.UP -> {
                eyeOffset1 = Offset(centerX - width * 0.25f, centerY - height * 0.25f)
                eyeOffset2 = Offset(centerX + width * 0.25f, centerY - height * 0.25f)
            }
            Direction.DOWN -> {
                eyeOffset1 = Offset(centerX - width * 0.25f, centerY + height * 0.25f)
                eyeOffset2 = Offset(centerX + width * 0.25f, centerY + height * 0.25f)
            }
            Direction.LEFT -> {
                eyeOffset1 = Offset(centerX - width * 0.25f, centerY - height * 0.25f)
                eyeOffset2 = Offset(centerX - width * 0.25f, centerY + height * 0.25f)
            }
            Direction.RIGHT -> {
                eyeOffset1 = Offset(centerX + width * 0.25f, centerY - height * 0.25f)
                eyeOffset2 = Offset(centerX + width * 0.25f, centerY + height * 0.25f)
            }
        }

        // Draw whites of eyes
        drawCircle(color = Color.White, radius = eyeSize, center = eyeOffset1)
        drawCircle(color = Color.White, radius = eyeSize, center = eyeOffset2)

        // Draw black pupils
        drawCircle(color = Color.Black, radius = pupilSize, center = eyeOffset1)
        drawCircle(color = Color.Black, radius = pupilSize, center = eyeOffset2)
    }
}

@Composable
fun VirtualDpad(
    activeDirection: Direction,
    onDirectionChange: (Direction) -> Unit,
    isPaused: Boolean,
    onPauseToggle: () -> Unit,
    themeColors: ThemeColors
) {
    // Elegant circular keypad representing high fidelity console D-pads
    Box(
        modifier = Modifier
            .size(170.dp)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        // Dpad backing plate
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(themeColors.surface)
                .border(2.dp, themeColors.accent.copy(alpha = 0.5f), CircleShape)
        )

        // UP Button
        DpadButton(
            direction = Direction.UP,
            icon = Icons.Filled.KeyboardArrowUp,
            active = activeDirection == Direction.UP,
            themeColors = themeColors,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 4.dp),
            onClick = { onDirectionChange(Direction.UP) }
        )

        // DOWN Button
        DpadButton(
            direction = Direction.DOWN,
            icon = Icons.Filled.KeyboardArrowDown,
            active = activeDirection == Direction.DOWN,
            themeColors = themeColors,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 4.dp),
            onClick = { onDirectionChange(Direction.DOWN) }
        )

        // LEFT Button
        DpadButton(
            direction = Direction.LEFT,
            icon = Icons.Filled.ArrowBack, // Standard left arrow
            active = activeDirection == Direction.LEFT,
            themeColors = themeColors,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 4.dp),
            onClick = { onDirectionChange(Direction.LEFT) }
        )

        // RIGHT Button
        DpadButton(
            direction = Direction.RIGHT,
            icon = Icons.Filled.PlayArrow, // Standard right arrow
            active = activeDirection == Direction.RIGHT,
            themeColors = themeColors,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 4.dp),
            onClick = { onDirectionChange(Direction.RIGHT) }
        )

        // Center hub plate (Pause option)
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    if (isPaused) themeColors.accent else themeColors.unselected
                )
                .border(
                    1.dp,
                    if (isPaused) themeColors.accent else themeColors.accent.copy(alpha = 0.3f),
                    CircleShape
                )
                .clickable { onPauseToggle() }
                .testTag("dpad_pause"),
            contentAlignment = Alignment.Center
        ) {
            val iconColor = if (isPaused) Color.Black else themeColors.textPrimary
            if (isPaused) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Resume",
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 4.dp, height = 14.dp)
                            .background(iconColor, shape = RoundedCornerShape(1.dp))
                    )
                    Box(
                        modifier = Modifier
                            .size(width = 4.dp, height = 14.dp)
                            .background(iconColor, shape = RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun DpadButton(
    direction: Direction,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    themeColors: ThemeColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(
                if (active) themeColors.accent else themeColors.unselected
            )
            .border(
                1.dp,
                if (active) themeColors.accent else themeColors.accent.copy(alpha = 0.15f),
                CircleShape
            )
            .clickable(onClick = onClick)
            .testTag("dpad_${direction.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = direction.name,
            tint = if (active) Color.Black else themeColors.textPrimary,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun LeaderboardSection(
    highScores: List<ScoreEntry>,
    themeColors: ThemeColors,
    modifier: Modifier = Modifier,
    onClearClick: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()) }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Filled.Star, contentDescription = "Leaderboard", tint = themeColors.accent)
                Text(
                    text = "SCORE LOGS",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeColors.accent,
                    fontFamily = FontFamily.Monospace
                )
            }

            if (highScores.isNotEmpty()) {
                Text(
                    text = "Clear All",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Red.copy(alpha = 0.8f),
                    modifier = Modifier
                        .clickable { onClearClick() }
                        .padding(4.dp)
                        .testTag("clear_leaderboard_button")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (highScores.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = "Empty list",
                        tint = themeColors.textSecondary.copy(alpha = 0.3f),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "No arena records yet.",
                        fontSize = 12.sp,
                        color = themeColors.textSecondary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Play a game to log stats!",
                        fontSize = 10.sp,
                        color = themeColors.textSecondary.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(highScores) { record ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(themeColors.unselected.copy(alpha = 0.3f))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${record.gameMode} • ${record.difficulty}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = themeColors.textPrimary
                            )
                            Text(
                                text = dateFormatter.format(Date(record.timestamp)),
                                fontSize = 9.sp,
                                color = themeColors.textSecondary
                            )
                        }

                        Text(
                            text = "${record.score} pts",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = themeColors.accent
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickThemeSelectorSection(
    currentTheme: ThemePalette,
    themeColors: ThemeColors,
    onThemeSelected: (ThemePalette) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "ARENA THEME SELECTOR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = themeColors.textSecondary,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ThemePalette.values().forEach { palette ->
                val selected = palette == currentTheme
                val colors = getThemeColors(palette)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.background)
                        .border(
                            1.dp,
                            if (selected) themeColors.accent else colors.accent.copy(alpha = 0.3f),
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onThemeSelected(palette) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = palette.label.split(" ").first(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.accent
                    )
                }
            }
        }
    }
}

@Composable
fun GameOverOverlay(
    state: SnakeGameState,
    viewModel: GameViewModel,
    themeColors: ThemeColors
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable(enabled = false) {}, // Swallow clicks
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(16.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = themeColors.surface
            ),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Game over banner
                Icon(
                    Icons.Filled.Warning, // Red alarm warning icon
                    contentDescription = "Game over",
                    tint = Color.Red,
                    modifier = Modifier.size(54.dp)
                )

                Text(
                    text = "CRASH DETECTED",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = Color.Red,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Your snake collided with a barrier!",
                    fontSize = 13.sp,
                    color = themeColors.textSecondary,
                    textAlign = TextAlign.Center
                )

                HorizontalDivider(color = themeColors.accent.copy(alpha = 0.2f))

                // Score stats display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "FINAL SCORE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = themeColors.textSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${state.score}",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = themeColors.accent,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "HIGH RECORD",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = themeColors.textSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${state.currentHighScore}",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFFD700), // Gold
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // High score badge
                if (state.score > 0 && state.score >= state.currentHighScore) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFFD700).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFFFFD700), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🏆 NEW PERSONAL BEST RECORD! 🏆",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFFD700)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Actions (Touch target compliant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.resetGame() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("game_over_menu_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = themeColors.unselected,
                            contentColor = themeColors.textPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "Main Menu", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.startGame() },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("game_over_retry_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = themeColors.accent,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "Play Again", fontSize = 14.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

// Color conversion helper
fun interpolateColor(start: Color, end: Color, fraction: Float): Color {
    return Color(
        red = start.red + (end.red - start.red) * fraction,
        green = start.green + (end.green - start.green) * fraction,
        blue = start.blue + (end.blue - start.blue) * fraction,
        alpha = start.alpha + (end.alpha - start.alpha) * fraction
    )
}

// Visual Theme Engine models
data class ThemeColors(
    val background: Color,
    val surface: Color,
    val unselected: Color,
    val primary: Color,
    val accent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textOnPrimary: Color,
    val gridBg: Color,
    val gridLine: Color,
    val snakeHead: Color,
    val snakeTail: Color,
    val apple: Color,
    val obstacleColor: Color
)

fun getThemeColors(palette: ThemePalette): ThemeColors {
    return when (palette) {
        ThemePalette.EMERALD_GREEN -> ThemeColors(
            background = Color(0xFF0C130F),
            surface = Color(0xFF14221A),
            unselected = Color(0xFF20352A),
            primary = Color(0xFF109D58),
            accent = Color(0xFF3DDC84), // Android light green
            textPrimary = Color(0xFFE2EFE7),
            textSecondary = Color(0xFF94B5A1),
            textOnPrimary = Color.White,
            gridBg = Color(0xFF090E0B),
            gridLine = Color(0xFF16251C),
            snakeHead = Color(0xFF3DDC84),
            snakeTail = Color(0xFF0F5A31),
            apple = Color(0xFFFF4D4D),
            obstacleColor = Color(0xFF5A6860)
        )
        ThemePalette.CYBERPUNK -> ThemeColors(
            background = Color(0xFF0C0314),
            surface = Color(0xFF1A092A),
            unselected = Color(0xFF2C1342),
            primary = Color(0xFFD300C5),
            accent = Color(0xFF00FFCC), // Cyber neon teal
            textPrimary = Color(0xFFF9E7FF),
            textSecondary = Color(0xFFA57EB9),
            textOnPrimary = Color.Black,
            gridBg = Color(0xFF07010C),
            gridLine = Color(0xFF210E34),
            snakeHead = Color(0xFF00FFCC),
            snakeTail = Color(0xFF8B008B),
            apple = Color(0xFFFF007F), // Neon hot pink
            obstacleColor = Color(0xFF4B3263)
        )
        ThemePalette.MONOCHROME -> ThemeColors(
            background = Color(0xFF0E0E0E),
            surface = Color(0xFF1A1A1A),
            unselected = Color(0xFF2A2A2A),
            primary = Color(0xFFE0E0E0),
            accent = Color(0xFF708090), // Slate grey
            textPrimary = Color.White,
            textSecondary = Color(0xFF888888),
            textOnPrimary = Color.Black,
            gridBg = Color(0xFF080808),
            gridLine = Color(0xFF1E1E1E),
            snakeHead = Color(0xFFCCCCCC),
            snakeTail = Color(0xFF444444),
            apple = Color(0xFF999999),
            obstacleColor = Color(0xFF4A4A4A)
        )
        ThemePalette.COSMIC_VOLT -> ThemeColors(
            background = Color(0xFF040614),
            surface = Color(0xFF0D122B),
            unselected = Color(0xFF1C2248),
            primary = Color(0xFF7000FF),
            accent = Color(0xFFFAD02C), // Electric Volt Yellow
            textPrimary = Color(0xFFEDEEF7),
            textSecondary = Color(0xFF8A93BE),
            textOnPrimary = Color.White,
            gridBg = Color(0xFF02030A),
            gridLine = Color(0xFF141935),
            snakeHead = Color(0xFFFAD02C),
            snakeTail = Color(0xFF4B0082),
            apple = Color(0xFF7000FF),
            obstacleColor = Color(0xFF424A75)
        )
    }
}
