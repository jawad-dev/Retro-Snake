package com.example.ui

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}

enum class Difficulty(val delayMs: Long, val label: String) {
    EASY(240L, "Easy"),
    MEDIUM(160L, "Medium"),
    HARD(100L, "Hard")
}

enum class GameMode(val label: String, val description: String) {
    CLASSIC("Classic", "Traditional arcade rules. Eat and grow. Avoid walls and your own body."),
    OBSTACLES("Obstacles", "The arena is scattered with solid stone obstacles! Maneuver carefully."),
    SPEED_UP("Speed Up", "Progressive adrenaline! The game speeds up with each apple consumed.")
}

enum class ThemePalette(val label: String) {
    EMERALD_GREEN("Emerald Neon"),
    CYBERPUNK("Cyberpunk Glow"),
    MONOCHROME("Classic Retro"),
    COSMIC_VOLT("Cosmic Volt")
}

data class SnakeGameState(
    val snake: List<Pair<Int, Int>> = listOf(Pair(10, 10), Pair(10, 11), Pair(10, 12)),
    val direction: Direction = Direction.UP,
    val food: Pair<Int, Int> = Pair(5, 5),
    val specialFood: Pair<Int, Int>? = null, // Golden apples
    val specialFoodExpiry: Int = 0, // In steps/ticks
    val obstacles: List<Pair<Int, Int>> = emptyList(),
    val score: Int = 0,
    val isGameOver: Boolean = false,
    val isPaused: Boolean = false,
    val hasStarted: Boolean = false,
    val wrapAround: Boolean = false,
    val selectedDifficulty: Difficulty = Difficulty.MEDIUM,
    val selectedMode: GameMode = GameMode.CLASSIC,
    val currentHighScore: Int = 0,
    val theme: ThemePalette = ThemePalette.EMERALD_GREEN
)
