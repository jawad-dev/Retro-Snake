package com.example.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundManager {
    private val scope = CoroutineScope(Dispatchers.IO)
    var isMuted: Boolean = false

    fun playTone(frequency: Double, durationMs: Int) {
        if (isMuted) return
        scope.launch {
            try {
                val sampleRate = 8000
                val numSamples = (durationMs * sampleRate / 1000)
                val buffer = ShortArray(numSamples)
                
                for (i in 0 until numSamples) {
                    val angle = 2.0 * Math.PI * i * frequency / sampleRate
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.4).toInt().toShort() // Keep volume pleasant
                }
                
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                
                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                
                // Allow tone to play through
                kotlinx.coroutines.delay(durationMs.toLong() + 50)
                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playEat() {
        // High-pitched retro blip
        playTone(987.77, 80) // B5
    }

    fun playDie() {
        // Slow downward pitch slide
        scope.launch {
            if (isMuted) return@launch
            try {
                val sampleRate = 8000
                val durationMs = 400
                val numSamples = (durationMs * sampleRate / 1000)
                val buffer = ShortArray(numSamples)
                
                for (i in 0 until numSamples) {
                    // Slide frequency down from 400Hz to 100Hz
                    val fraction = i.toDouble() / numSamples
                    val currentFreq = 400.0 - (fraction * 300.0)
                    val angle = 2.0 * Math.PI * i * currentFreq / sampleRate
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.4).toInt().toShort()
                }
                
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                
                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                
                kotlinx.coroutines.delay(durationMs.toLong() + 50)
                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playButton() {
        playTone(523.25, 60) // C5
    }

    fun playHighScore() {
        // High score arpeggio: C5 -> E5 -> G5 -> C6
        scope.launch {
            playTone(523.25, 100)
            kotlinx.coroutines.delay(100)
            playTone(659.25, 100)
            kotlinx.coroutines.delay(100)
            playTone(783.99, 100)
            kotlinx.coroutines.delay(100)
            playTone(1046.50, 200)
        }
    }
}
