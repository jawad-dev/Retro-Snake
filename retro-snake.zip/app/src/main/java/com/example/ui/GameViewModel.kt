package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameDatabase
import com.example.data.ScoreEntry
import com.example.data.ScoreRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {

    val gridSize = 20

    private val scoreDao = GameDatabase.getDatabase(application).scoreDao()
    private val repository = ScoreRepository(scoreDao)

    private val _state = MutableStateFlow(SnakeGameState())
    val state: StateFlow<SnakeGameState> = _state.asStateFlow()

    private val _highScores = MutableStateFlow<List<ScoreEntry>>(emptyList())
    val highScores: StateFlow<List<ScoreEntry>> = _highScores.asStateFlow()

    val soundManager = SoundManager()

    private var gameLoopJob: Job? = null
    private var lastMovingDirection: Direction = Direction.UP

    init {
        // Fetch high scores from database
        viewModelScope.launch {
            repository.allHighScores.collect { scores ->
                _highScores.value = scores
            }
        }
        
        // Load initial high score for selected config
        updateHighScoreForCurrentConfig()
    }

    fun setMuted(muted: Boolean) {
        soundManager.isMuted = muted
    }

    fun changeTheme(theme: ThemePalette) {
        soundManager.playButton()
        _state.update { it.copy(theme = theme) }
    }

    fun changeDifficulty(difficulty: Difficulty) {
        if (!_state.value.hasStarted) {
            soundManager.playButton()
            _state.update { it.copy(selectedDifficulty = difficulty) }
            updateHighScoreForCurrentConfig()
        }
    }

    fun changeGameMode(mode: GameMode) {
        if (!_state.value.hasStarted) {
            soundManager.playButton()
            _state.update { it.copy(selectedMode = mode) }
            updateHighScoreForCurrentConfig()
        }
    }

    fun toggleWrapAround(wrap: Boolean) {
        if (!_state.value.hasStarted) {
            soundManager.playButton()
            _state.update { it.copy(wrapAround = wrap) }
        }
    }

    private fun updateHighScoreForCurrentConfig() {
        viewModelScope.launch {
            val modeStr = _state.value.selectedMode.name
            val diffStr = _state.value.selectedDifficulty.name
            repository.getHighScoreForConfig(modeStr, diffStr).collect { high ->
                _state.update { it.copy(currentHighScore = high ?: 0) }
            }
        }
    }

    fun startGame() {
        soundManager.playButton()
        if (gameLoopJob != null) return

        // Set up initial state
        val initialSnake = listOf(
            Pair(10, 10),
            Pair(10, 11),
            Pair(10, 12)
        )
        val initialDirection = Direction.UP
        lastMovingDirection = Direction.UP

        val mode = _state.value.selectedMode
        val obstacles = if (mode == GameMode.OBSTACLES) {
            generateRandomObstacles(initialSnake)
        } else {
            emptyList()
        }

        val food = generateRandomFoodPosition(initialSnake, obstacles, null)

        _state.update {
            it.copy(
                snake = initialSnake,
                direction = initialDirection,
                food = food,
                specialFood = null,
                specialFoodExpiry = 0,
                obstacles = obstacles,
                score = 0,
                isGameOver = false,
                isPaused = false,
                hasStarted = true
            )
        }

        startGameLoop()
    }

    fun pauseResumeGame() {
        soundManager.playButton()
        val currentState = _state.value
        if (!currentState.hasStarted || currentState.isGameOver) return

        if (currentState.isPaused) {
            _state.update { it.copy(isPaused = false) }
            startGameLoop()
        } else {
            _state.update { it.copy(isPaused = true) }
            gameLoopJob?.cancel()
            gameLoopJob = null
        }
    }

    fun resetGame() {
        soundManager.playButton()
        gameLoopJob?.cancel()
        gameLoopJob = null
        _state.update {
            it.copy(
                snake = listOf(Pair(10, 10), Pair(10, 11), Pair(10, 12)),
                direction = Direction.UP,
                score = 0,
                isGameOver = false,
                isPaused = false,
                hasStarted = false,
                specialFood = null,
                specialFoodExpiry = 0
            )
        }
    }

    fun changeDirection(newDirection: Direction) {
        val currentDir = _state.value.direction
        // Prevent instant complete reversals (e.g. going UP and pressing DOWN)
        val isValid = when (newDirection) {
            Direction.UP -> lastMovingDirection != Direction.DOWN
            Direction.DOWN -> lastMovingDirection != Direction.UP
            Direction.LEFT -> lastMovingDirection != Direction.RIGHT
            Direction.RIGHT -> lastMovingDirection != Direction.LEFT
        }

        if (isValid && !_state.value.isPaused && !_state.value.isGameOver) {
            _state.update { it.copy(direction = newDirection) }
        }
    }

    private fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            while (true) {
                val delayTime = calculateDelay()
                delay(delayTime)
                executeGameTick()
            }
        }
    }

    private fun calculateDelay(): Long {
        val baseDelay = _state.value.selectedDifficulty.delayMs
        return if (_state.value.selectedMode == GameMode.SPEED_UP) {
            // Speed up progressively as score increases, minimum 65ms
            maxOf(65L, baseDelay - (_state.value.score / 10) * 8L)
        } else {
            baseDelay
        }
    }

    private fun executeGameTick() {
        val currentState = _state.value
        if (currentState.isGameOver || currentState.isPaused) return

        val snake = currentState.snake
        val head = snake.first()
        val direction = currentState.direction
        lastMovingDirection = direction

        // Compute prospective new head
        var newHeadX = head.first
        var newHeadY = head.second

        when (direction) {
            Direction.UP -> newHeadY--
            Direction.DOWN -> newHeadY++
            Direction.LEFT -> newHeadX--
            Direction.RIGHT -> newHeadX++
        }

        // Edge/Wall logic
        if (currentState.wrapAround) {
            newHeadX = (newHeadX + gridSize) % gridSize
            newHeadY = (newHeadY + gridSize) % gridSize
        } else {
            if (newHeadX < 0 || newHeadX >= gridSize || newHeadY < 0 || newHeadY >= gridSize) {
                triggerGameOver()
                return
            }
        }

        val finalHead = Pair(newHeadX, newHeadY)

        // Collision with self (exclude tail end tip ONLY if it's not growing,
        // but checking basic list inclusion is safer/cleaner and matches retro)
        if (snake.contains(finalHead)) {
            triggerGameOver()
            return
        }

        // Collision with obstacles
        if (currentState.obstacles.contains(finalHead)) {
            triggerGameOver()
            return
        }

        // Movement/Eating logic
        var newSnake = snake.toMutableList()
        var newScore = currentState.score
        var newFood = currentState.food
        var newSpecialFood = currentState.specialFood
        var newSpecialExpiry = currentState.specialFoodExpiry

        // Check if golden special food is eaten
        if (newSpecialFood != null && finalHead == newSpecialFood) {
            newSnake.add(0, finalHead)
            newScore += 30
            soundManager.playEat()
            newSpecialFood = null
            newSpecialExpiry = 0
        }
        // Check if regular food is eaten
        else if (finalHead == newFood) {
            newSnake.add(0, finalHead)
            newScore += 10
            soundManager.playEat()

            // Dynamic golden apple spawn chance (15% chance if score > 30 and no special food exists)
            if (newSpecialFood == null && newScore >= 30 && Random.nextFloat() < 0.15f) {
                newSpecialFood = generateRandomFoodPosition(newSnake, currentState.obstacles, null)
                newSpecialExpiry = 15 // Active for 15 moves
            }

            // Spawn next normal apple
            newFood = generateRandomFoodPosition(newSnake, currentState.obstacles, newSpecialFood)
        } else {
            // Standard move: add new head, remove tail
            newSnake.add(0, finalHead)
            if (newSnake.isNotEmpty()) {
                newSnake.removeAt(newSnake.size - 1)
            }
        }

        // Golden food timeout ticking
        if (newSpecialFood != null) {
            newSpecialExpiry--
            if (newSpecialExpiry <= 0) {
                newSpecialFood = null
                newSpecialExpiry = 0
            }
        }

        _state.update {
            it.copy(
                snake = newSnake,
                score = newScore,
                food = newFood,
                specialFood = newSpecialFood,
                specialFoodExpiry = newSpecialExpiry
            )
        }
    }

    private fun generateRandomFoodPosition(
        snake: List<Pair<Int, Int>>,
        obstacles: List<Pair<Int, Int>>,
        otherFood: Pair<Int, Int>?
    ): Pair<Int, Int> {
        var tries = 0
        while (tries < 200) {
            val randomX = Random.nextInt(gridSize)
            val randomY = Random.nextInt(gridSize)
            val pos = Pair(randomX, randomY)
            if (!snake.contains(pos) && !obstacles.contains(pos) && pos != otherFood) {
                return pos
            }
            tries++
        }
        // Fallback
        return Pair(0, 0)
    }

    private fun generateRandomObstacles(snake: List<Pair<Int, Int>>): List<Pair<Int, Int>> {
        val obstacles = mutableListOf<Pair<Int, Int>>()
        // Place between 5 and 10 obstacles, keeping them away from the immediate snake start area
        val count = Random.nextInt(5, 10)
        var tries = 0
        while (obstacles.size < count && tries < 100) {
            val randomX = Random.nextInt(1, gridSize - 1)
            val randomY = Random.nextInt(1, gridSize - 1)
            val pos = Pair(randomX, randomY)
            
            // Keep obstacles safe from the starting snake area (centered around 10,10)
            val distToCenter = Math.abs(randomX - 10) + Math.abs(randomY - 10)
            if (distToCenter > 3 && !snake.contains(pos) && !obstacles.contains(pos)) {
                obstacles.add(pos)
            }
            tries++
        }
        return obstacles
    }

    private fun triggerGameOver() {
        soundManager.playDie()
        gameLoopJob?.cancel()
        gameLoopJob = null

        val finalState = _state.value
        _state.update { it.copy(isGameOver = true) }

        // Save score if it's positive
        if (finalState.score > 0) {
            viewModelScope.launch {
                val isNewRecord = finalState.score > finalState.currentHighScore
                
                repository.insertScore(
                    ScoreEntry(
                        score = finalState.score,
                        gameMode = finalState.selectedMode.name,
                        difficulty = finalState.selectedDifficulty.name
                    )
                )
                
                if (isNewRecord) {
                    soundManager.playHighScore()
                    updateHighScoreForCurrentConfig()
                }
            }
        }
    }

    fun clearHighScores() {
        soundManager.playButton()
        viewModelScope.launch {
            repository.clearAllScores()
            _state.update { it.copy(currentHighScore = 0) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        gameLoopJob?.cancel()
    }
}
